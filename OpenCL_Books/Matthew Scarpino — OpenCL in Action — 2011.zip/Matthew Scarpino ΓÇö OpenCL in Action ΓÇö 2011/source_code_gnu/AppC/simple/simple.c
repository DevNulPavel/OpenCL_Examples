extern void hello1();
extern void hello2();

int main() {
   hello1();
   hello2();
}
