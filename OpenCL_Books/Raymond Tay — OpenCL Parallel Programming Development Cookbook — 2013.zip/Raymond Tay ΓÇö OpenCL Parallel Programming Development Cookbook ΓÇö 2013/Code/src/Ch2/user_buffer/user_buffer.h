
// Simulating the OpenCL vector data type: int4
typedef struct UserData {
    int x;
    int y;
    int z;
    int w;
} UserData;



