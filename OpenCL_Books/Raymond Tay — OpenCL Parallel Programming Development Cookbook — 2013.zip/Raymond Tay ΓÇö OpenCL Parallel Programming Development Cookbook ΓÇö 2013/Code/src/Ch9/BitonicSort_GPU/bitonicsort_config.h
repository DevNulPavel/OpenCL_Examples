#define DEBUG
#define DEBUG_VERBOSE
/* #undef USE_SHARED_MEM */
/* #undef USE_SHARED_MEM_2 */
