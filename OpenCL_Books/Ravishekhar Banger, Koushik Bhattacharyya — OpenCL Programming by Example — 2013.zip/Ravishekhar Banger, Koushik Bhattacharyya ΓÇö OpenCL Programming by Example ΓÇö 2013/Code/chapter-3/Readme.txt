There are three samples in this chapter:

histogram
This sample needs an input color image file. The format of this file should be BMP file format. Copy this image from the input folder to the place where your executable is built.
The input file name is hard coded to read the file name sample_color.bmp. The histogram sample will compute the histogram of the image for each color component R G B.
A more optimized version of histogram is implemented in chapter 8 where in we discuss the different optimization technique

